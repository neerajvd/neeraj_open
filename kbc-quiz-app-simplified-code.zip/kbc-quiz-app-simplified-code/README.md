# KBC quiz game

## Setup
to create requirements file
    pip freeze > requirements.txt

to install all requirements 
    pip install -r requirements.txt
